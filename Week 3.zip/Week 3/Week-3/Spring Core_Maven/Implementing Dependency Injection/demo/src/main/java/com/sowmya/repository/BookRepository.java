package com.sowmya.repository;

public interface BookRepository {
    void save(String bookTitle);
}