package com.example.Repository;

public class BookRepository {
    public void fetchBooks() {
        System.out.println("Fetching books from the database...");
    }
}
