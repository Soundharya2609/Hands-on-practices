import "./App.css";

function App() {
  return <h1>Welcome to the first React session</h1>;
}

export default App;
